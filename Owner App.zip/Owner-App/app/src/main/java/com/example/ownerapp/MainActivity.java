package com.example.ownerapp;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Orders order1=new Orders();
        Orders order2=new Orders();
        order1.RoomNo=104;
        order2.RoomNo=302;
        order1.time="10:00 am";
        order2.time="1:00 pm";
        order1.items.add("North Indian Thali");
        order1.items.add("South Indian Thali");
        order1.items.add("Ironing T-shirt");
        order1.items.add("Ironing Pants");
        order1.quantity.add(1);
        order1.quantity.add(1);
        order1.quantity.add(1);
        order1.quantity.add(1);
        order2.quantity.add(1);
        order2.items.add("North Indian Thali");
        order1.date="3 Feb, 2022";
        order2.date="2 Feb, 2022";

        List<Orders> list=new ArrayList<Orders>();
        list.add(order1);
        list.add(order2);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.Recycle_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        CustomAdapter c=new CustomAdapter(this,list);
        recyclerView.setAdapter(c);

    }
}