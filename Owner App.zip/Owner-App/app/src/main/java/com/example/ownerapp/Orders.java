package com.example.ownerapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Orders {
    public int RoomNo;
    public String date;
    public String time;
    List<String> items = new ArrayList<String>();
    List<Integer> quantity = new ArrayList<Integer>();

}
